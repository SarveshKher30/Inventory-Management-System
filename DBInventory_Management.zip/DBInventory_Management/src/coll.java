
import com.mongodb.BasicDBObject;


class coll {

    static void Register(BasicDBObject doc) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
