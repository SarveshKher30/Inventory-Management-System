
class getjTextField5 {

    static String getText;
    
}
